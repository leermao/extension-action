document.body.style.border = '1px solid blue';
